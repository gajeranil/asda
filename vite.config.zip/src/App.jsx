
import React from 'react'
import './App.css'
import './index.css'
import Logo from './assets/asset 0.png'
// import SearchIcon from '@mui/icons-material/Search';

export default function App() {


  return (
    <>
      <div className='header bg-[#f9f3f0] py-4 px-24'>
        <div className='header bg-[#f9f3f0] w-full h-auto flex justify-between  pb-3'>
          <div className='left-part'>
            <div className='left-main-part'>
              <select className='bg-transparent cursor-pointer mx-3 text-sm text-gray-700'>
                <option className='bg-white hover:bg-pink-800'>English</option>
                <option className='bg-white'>Arabic</option>
                <option className='bg-white'>spanish</option>
              </select>
              <select className='bg-transparent cursor-pointer text-sm text-gray-700'>
                <option className='bg-white'>USD</option>
                <option className='bg-white'>AUD</option>
                <option className='bg-white'>EUR</option>
              </select>

            </div>
          </div>
          <div className='right-part'>
            <div className='list-none flex text-sm text-gray-700 '>
              <li className='mx-4 hover:text-blue-700 duration-500 cursor-pointer'>Help</li>
              <li className='mx-4 hover:text-blue-700 duration-500 cursor-pointer'>Join Us</li>
              <li className='mx-4 hover:text-blue-700 duration-500 cursor-pointer'>Sign In</li>
            </div>
          </div>

        </div>
        {/* navbar */}
        <div className='navbar py-5 px-12 h-22 bg-white rounded-lg mx-3 flex  justify-between shadow-lg'>
          <div className='logo'>
            <img src={Logo} className='w-36 h-10' alt="" />
          </div>
          <div className='navbar flex '>
            <select className='bg-transparent cursor-pointer text-base font-bold font-sans text-gray-700 mx-7 border-b-2 border-black'>
              <option className='bg-white'>Home</option>
              <option className='bg-white'>AUD</option>
              <option className='bg-white'>EUR</option>
            </select>
            <select className='bg-transparent cursor-pointer text-base text-gray-700 mx-7 font-bold font-sans'>
              <option className='bg-white'>Shop</option>
              <option className='bg-white'>AUD</option>
              <option className='bg-white'>EUR</option>
            </select>
            <select className='bg-transparent cursor-pointer text-base text-gray-700 mx-7 font-bold font-sans'>
              <option className='bg-white'>Pages</option>
              <option className='bg-white'>AUD</option>
              <option className='bg-white'>EUR</option>
            </select>
            <option className='text-base py-2.5 mx-7 text-gray-700 font-bold font-sans'>About</option>
            <select className='bg-transparent cursor-pointer text-base text-gray-700 mx-7 font-bold font-sans'>
              <option className='bg-white'>USD</option>
              <option className='bg-white'>AUD</option>
              <option className='bg-white'>EUR</option>
            </select>
            <option className='text-base py-2.5 text-gray-700 mx-7 font-bold font-sans'>Contact</option>
          </div>
          <div className='icons'>
            {/* <SearchIcon></SearchIcon> */}
          </div>
        </div>
      </div>
    </>
  )
}
