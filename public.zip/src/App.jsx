
import React from 'react'
import './App.css'
import Logo from './assets/asset 0.png'
import Thumb from './assets/thumb-up-svgrepo-com(1).svg'
import Delivery from './assets/asset 40.png'
import Gurantee from './assets/asset 41.png'
import Policy from './assets/asset 42.png'
import Return from './assets/asset 43.png'
import Quality from './assets/asset 44.png'
import Sound from './assets/asset 45.png'
import Glass from './assets/asset 46.png'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faArrowRightLong } from '@fortawesome/free-solid-svg-icons'
import { faMagnifyingGlass } from '@fortawesome/free-solid-svg-icons'
import { faCartShopping } from '@fortawesome/free-solid-svg-icons'
import { faHeart } from '@fortawesome/free-solid-svg-icons'
import { faUser } from '@fortawesome/free-solid-svg-icons'

// import ClickOn6 from './Clickon6.jsx'

export default function App() {
  return (
    <>
      <div className='header bg-[#f9f3f0] py-4 px-24'>
        <div className='header bg-[#f9f3f0] w-full h-auto flex justify-between  pb-3'>
          <div className='left-part'>
            <div className='left-main-part ml-3'>
              <div className="dropdown flex ">
                <div className='english-button group'>
                  <button className="btn relative text-sm text-gray-500 font-sans " type="button">
                    English
                  </button>
                  <ul className="dropdown-menu bg-white p-2 absolute  bg-repeat-rounded opacity-0 group-hover:opacity-100 duration-500 shadow-xl">
                    <li><a className="dropdown-item  hover:bg-pink-600 block rounded px-2 duration-500 hover:text-white" href="#">English</a></li>
                    <li><a className="dropdown-item hover:bg-pink-600 block rounded px-2 duration-500 hover:text-white" href="#">Arabic</a></li>
                    <li><a className="dropdown-item hover:bg-pink-600 block rounded px-2 duration-500 hover:text-white" href="#">Spanish</a></li>
                  </ul>
                </div>
                <div className='usd-button group'>
                  <button className="btn relative ml-3 text-sm text-gray-500 font-sans " type="button">
                    USD
                  </button>
                  <ul className="dropdown-menu bg-white p-2 ml-3 absolute bg-repeat-rounded opacity-0 group-hover:opacity-100 duration-500 shadow-xl">
                    <li><a className="dropdown-item  hover:bg-pink-600 block rounded px-2 duration-500 hover:text-white" href="#">USD</a></li>
                    <li><a className="dropdown-item hover:bg-pink-600 block rounded px-2 duration-500 hover:text-white" href="#">AUD</a></li>
                    <li><a className="dropdown-item hover:bg-pink-600 block rounded px-2 duration-500 hover:text-white" href="#">EUR</a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className='right-part'>
            <div className='list-none flex text-sm text-gray-700 '>
              <li className='mx-4 hover:text-blue-700 duration-500 cursor-pointer'>Help</li>
              <li className='mx-4 hover:text-blue-700 duration-500 cursor-pointer'>Join Us</li>
              <li className='mx-4 hover:text-blue-700 duration-500 cursor-pointer'>Sign In</li>
            </div>
          </div>

        </div>
        {/* navbar */}
        <div className='navbar py-5 px-12 h-22 bg-white rounded-lg mx-3 flex  justify-between shadow-lg'>
          <div className='logo'>
            <img src={Logo} className='w-36 h-10' alt="" />
          </div>
          <div className='navbar flex '>
            <div className='home group'>
              <button class="btn relative font-bold  mx-7 font-sans" type="button">
                Home
              </button>
              <ul className="dropdown-menu bg-white p-6 absolute top-28 bg-repeat-rounded  opacity-0 group-hover:opacity-100 duration-500 shadow-md">
                <li><a className="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 text-pink-500" href="#">Home-Electronics</a></li>
                <li><a className="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Home-NFT</a></li>
                <li><a className="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Home-Fashion</a></li>
                <li><a className="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Home-Jewellery</a></li>
                <li><a className="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Home-Furniture</a></li>
                <li><a className="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Home-Multipurpose</a></li>
                <li><a className="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">RTL Version</a></li>
              </ul>
            </div>
            <div className='button group relative '>
              <button class="btn font-bold mx-7 font-sans before:content-[''] before:w-0  before:duration-700 before:h-0.5 before:absolute before:bottom-1  before:bg-black before:opacity-0  duration-300 before:group-hover:w-10  before:group-hover:opacity-100 " type="button">
                Shop
              </button>
              <ul class="dropdown-menu bg-white w-56 p-6 absolute top-12 left-[30%] bg-repeat-rounded opacity-0 group-hover:opacity-100 duration-500 shadow-md">
                <li><a class="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 text-pink-500" href="#">Shop With Sidebar</a></li>
                <li><a class="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Shop no sidebar</a></li>
                <li><a class="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Product Variation 1</a></li>
                <li><a class="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Product Variation 2</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Product Variation 3</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Product Variation 4</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Product Variation 5</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Product Variation 6</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Product Variation 7</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Product Variation 8</a></li>
              </ul>
            </div>
            <div className='button group relative'>
              <button class="btn font-bold mx-7 font-sans before:content-[''] before:w-0  before:duration-700 before:h-0.5 before:absolute before:bottom-1  before:bg-black before:opacity-0  duration-300 before:group-hover:w-10  before:group-hover:opacity-100 " type="button">
                Pages
              </button>
              <ul class="dropdown-menu bg-white w-56 p-6 absolute top-14 bg-repeat-rounded opacity-0 group-hover:opacity-100 duration-500 shadow-md">
                <li><a class="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 text-pink-500" href="#">Wishlist</a></li>
                <li><a class="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Cart</a></li>
                <li><a class="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Checkout</a></li>
                <li><a class="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Home-Account</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Sign Up</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Sign In</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Forgot Password</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Reset Password</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Privacy Policy</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Coming soon</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">404 Error</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Typography</a></li>
              </ul>
            </div>


            {/* <li class="group  relative dropdown list-none  px-4 text-black cursor-pointer font-bold text-base  tracking-wide">
        <a href='#' class='btn font-bold mx-7 font-sans before:content-[] before:w-0  before:duration-700 before:h-0.5 before:absolute before:bottom-1  before:bg-black before:opacity-0  duration-300 before:group-hover:w-10  before:group-hover:opacity-100 '>Dropdown</a>
        <div class="group-hover:block dropdown-menu absolute hidden h-auto top-14 duration-1000">

        <ul class="top-0 w-48 bg-white shadow px-6 py-8 duration-700">
            <li class="py-1"><a class="block  font-bold text-base  text-pink-500 cursor-pointer ">Item</a></li>
            <li class="py-1"><a class="block text-black font-bold text-base  duration-500  hover:text-pink-500 cursor-pointer">Item 2</a></li>
            <li class="py-1"><a class="block text-black font-bold text-base  duration-500 hover:text-pink-500 cursor-pointer">Item 3</a></li>
            <li class="py-1"><a class="block text-black font-bold text-base  duration-500 hover:text-pink-500 cursor-pointer">Item 4</a></li>
            <li class="py-1"><a class="block text-black font-bold text-base  duration-500 hover:text-pink-500 cursor-pointer">Item 5</a></li>
        </ul>
        </div>
    </li> */}

            <div className='button group relative'>
              <button class="btn font-bold mx-7 font-sans before:content-[''] before:w-0  before:duration-700 before:h-0.5 before:absolute before:bottom-1  before:bg-black before:opacity-0  duration-300 before:group-hover:w-12  before:group-hover:opacity-100 " type="button">
                About
              </button>

            </div>
            <div className='button group relative'>
              <button class="btn font-bold mx-7 font-sans before:content-[''] before:w-0  before:duration-700 before:h-0.5 before:absolute before:bottom-1  before:bg-black before:opacity-0  duration-300 before:group-hover:w-10  before:group-hover:opacity-100 " type="button">
                Blog
              </button>
              <ul class="dropdown-menu bg-white p-6 absolute w-56 top-14 bg-repeat-rounded opacity-0 group-hover:opacity-100 duration-500 shadow-md">
                <li><a class="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 text-pink-500" href="#">Home-Electronics</a></li>
                <li><a class="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Home-NFT</a></li>
                <li><a class="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Home-Fashion</a></li>
                <li><a class="dropdown-item   mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Home-Jewellery</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Home-Furniture</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">Home-Multipurpose</a></li>
                <li><a class="dropdown-item  mb-2 block font-semibold rounded px-2 duration-500 hover:text-pink-500" href="#">RTL Version</a></li>
              </ul>
            </div>
            <div className='button group relative'>
              <button class="btn font-bold mx-7 font-sans before:content-[''] before:w-0  before:duration-700 before:h-0.5 before:absolute before:bottom-1  before:bg-black before:opacity-0  duration-300 before:group-hover:w-14  before:group-hover:opacity-100 " type="button">
                Contact
              </button>

            </div>
          </div>
          <div className='icons flex justify-center'>
            <div className='icon  group relative z-10 '>
              <a href='#' className=' mx-3 before:content -[""] before:mx-3 before:absolute before:w-10 before:h-10 before:rounded-full before:bg-pink-500 before:-top-1.5 before:scale-0 before:-left-3 before:-z-10 before:group-hover:scale-100 before:duration-300 before:group-hover:'><FontAwesomeIcon icon={faMagnifyingGlass} className='group-hover:text-white duration-300 ' /></a>
            </div>
            <div className='icon  group relative z-10 '>
              <a href='#' className=' mx-3 before:content -[""] before:mx-3 before:absolute before:w-10 before:h-10 before:rounded-full before:bg-pink-500 before:-top-1.5 before:scale-0 before:-left-3 before:-z-10 before:group-hover:scale-100 before:duration-300 before:group-hover:'><FontAwesomeIcon icon={faHeart} className='group-hover:text-white duration-300 ' /></a>
            </div>
            <div className='icon  group relative z-10 '>
              <span className='cart-count w-6 h-6 absolute -top-3.5 -right-1 bg-[#3577f0] border-2 border-white text-center text-sm leading-[20px] text-white rounded-full'>3</span>
              <a href='#' className=' mx-3 before:content -[""] before:mx-3 before:absolute before:w-10 before:h-10 before:rounded-full before:bg-pink-500 before:-top-1.5 before:scale-0 before:-left-2.5 before:-z-10 before:group-hover:scale-100 before:duration-300 before:group-hover:'><FontAwesomeIcon icon={faCartShopping} className='group-hover:text-white duration-300 ' /></a>
            </div>
            <div className='icon  group relative z-10 '>
              <a href='#' className=' mx-3 before:content -[""] before:mx-3 before:absolute before:w-10 before:h-10 before:rounded-full before:bg-pink-500 before:-top-1.5 before:scale-0 before:-left-3 before:-z-10 before:group-hover:scale-100 before:duration-300 before:group-hover:'><FontAwesomeIcon icon={faUser} className='group-hover:text-white duration-300 ' /></a>
            </div>
          </div>
        </div>
      </div>
      <div className='why-us py-14 text-center mb-5'>
        <div className='subtitle justify-center  flex align-middle mb-3'>
          <img src={Thumb} className=' w-6 h-6 mr-3 mt-1' alt="" />
          <h3 className='mt-1 text-[#ff497c] font-semibold font-sans'>Why Us</h3>
        </div>
        <h1 className='text-4xl font-semibold text-gray-800 font-sans '>Why People Choose Us</h1>
      </div>
      <div className='main-image-section flex justify-center mb-20'>
        <div className='img-1 w-52 h-56 border-gray-200 border rounded mx-3 py-12 hover:shadow-xl duration-300'>
          <img src={Delivery} className='px-16 mx-2 mb-4' alt="" />
          <h1 className='text-center px-8 font-semibold font-sans text-gray-900'>Fast & Secure Delivery</h1>
        </div>
        <div className='img-2 w-52 h-56 border-gray-200 border rounded  mx-3 py-12 hover:shadow-xl duration-300'>
          <img src={Gurantee} className='px-16 mx-2 mb-4' alt="" />
          <h1 className='text-center px-8 font-semibold font-sans text-gray-900'>100% Guarantee On Product</h1>
        </div>
        <div className='img-3 w-52 h-56 border-gray-200 border rounded  mx-3 py-12 hover:shadow-xl duration-300'>
          <img src={Policy} className='px-16 mx-2 mb-4' alt="" />
          <h1 className='text-center px-8 font-semibold font-sans text-gray-900'>24 Hour Return Policy</h1>
        </div>
        <div className='img-4 w-52 h-56 border-gray-200 border rounded  mx-3 py-12 hover:shadow-xl duration-300'>
          <img src={Return} className='px-16 mx-2 mb-4' alt="" />
          <h1 className='text-center px-8 font-semibold font-sans text-gray-900'>24 Hour Return Policy</h1>
        </div>
        <div className='img-5 w-52 h-56 border-gray-200 border rounded mx-3 py-12 hover:shadow-xl duration-300'>
          <img src={Quality} className='px-16 mx-2 mb-4' alt="" />
          <h1 className='text-center px-8 font-semibold font-sans text-gray-900'>Next Level pro Quality</h1>
        </div>
      </div>

      <div className='blog-section flex justify-center  mb-8'>
        <div className='left-part w-[550px] overflow-hidden rounded-md mx-4 relative group'>
          <a href='#'><img src={Sound} className=' hover:scale-110 duration-500' alt="" /></a>
          <div className='content absolute top-11 right-32'>
            <h1 className='text-white text-4xl font-sans font-bold mb-5'>Rich sound,<br></br>for less.</h1>
            <a href='#' className='text-gray-600 font-medium group-hover:text-white duration-300 pr-3' >Collections<span className='ml-3  align-middle'><FontAwesomeIcon icon={faArrowRightLong} /></span></a>
          </div>
        </div>
        <div className='right-part w-[550px] overflow-hidden rounded-md mx-4 relative group'>
          <a href='#'><img src={Glass} className='hover:scale-110 duration-500' alt="" /></a>
          <div className='content2 absolute top-11 left-16 '>
            <a href='#' className='text-white font-medium group-hover:text-white duration-300 pr-3 leading-4 opacity-50 group-hover:opacity-100' >50% Offer In Winter</a>
            <h1 className='text-white text-4xl font-sans font-bold mb-5'>Get VR<br></br>Reality Glass</h1>
          </div>
        </div>
      </div>
     
    </>
  )
}
