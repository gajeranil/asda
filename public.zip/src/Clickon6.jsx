
     
    /* React Events Handling */
    
    
//     function alerts(){
//          console.log("hello !");
//     }

//     const handleClick = () => {
//          console.log("good morning")

//     }

//     const handleClick1 = () => {
//          alerts();
//          handleClick();
//     }

//  return (
//    <div>
//      <h1 className="text-6xl">React onClick Events</h1>
//      <button className="px-12 h-16 w-48 bg-purple-600 hover:text-white text-2xl m-10 hover:border-4 border-black" onClick={handleClick1}>ClickMeAll</button>
//    </div>
//  )
// }
// const handleClick1 = () => {
//     alerts();
//     handleClick();
//         }

const ClickOn6 = () => {
    const [state, setState] = useState({
       prop1: 'Hello',
       prop2: 'World',
       prop3: 'React',
       prop4: 'JS',
    });
   
    const printProp = (prop) => {
       console.log(prop);
    };
   
    const handleClick = () => {
       const newState = { state };
       const temp = newState.prop1;
       newState.prop1 = newState.prop2;
       newState.prop2 = newState.prop3;
       newState.prop3 = newState.prop4;
       newState.prop4 = temp;
       setState(newState);
       printProp(newState.prop1);
    };
   
    return (
       <div>
         <button onClick={handleClick}>Click Me</button>
       </div>
    );
   };
   

export default ClickOn6

