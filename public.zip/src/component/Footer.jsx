import React from 'react'
import { faPhone } from '@fortawesome/free-solid-svg-icons'
import { faEnvelopeOpen } from '@fortawesome/free-solid-svg-icons'
import { faFacebookF } from '@fortawesome/free-brands-svg-icons'
import { faInstagram } from '@fortawesome/free-brands-svg-icons'
import { faTwitter } from '@fortawesome/free-brands-svg-icons'
import { faLinkedinIn } from '@fortawesome/free-brands-svg-icons'
import { faDiscord } from '@fortawesome/free-brands-svg-icons'
import SecureDelivery from '../assets/asset 4.png'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import Guarantee from '../assets/asset 5.png'
import Returnpolicy from '../assets/asset 6.png'
import Support from '../assets/asset 7.png'
import Qrscan from '../assets/asset 8.png'
import Appstore from '../assets/asset 9.png'
import Googleplay from '../assets/asset 10.png'
import Paypal from '../assets/asset 11.png'
import Mastercard from '../assets/asset 12.png'
import Visa from '../assets/asset 14.png'
import Newsletter from '../assets/asset 47(1).jpeg'
import Newslettericon from '../assets/asset 39.png'


const Footer = () => {
    return (
        <>

            {/* <div className='Newsletter mx-auto w-[1130px] h-auto rounded-lg mb-8 relative'>
                <img src={Newsletter} className='rounded-lg' alt="" />
                <div className='newaletter-content absolute top-24 left-32'>
                    <div className='newsletter flex mb-3'>
                        <FontAwesomeIcon icon={faEnvelopeOpen} className='text-white bg-blue-500 p-2 rounded-full mr-3 ' /> <h1 className='text-blue-500 mt-1 font-semibold'>Newsletter</h1>
                    </div>
                    <h1 className='text-4xl font-sans font-bold mb-8 text-gray-800'>Get weekly update</h1>

                    <div className='flex  '>
                        <input type='text' className='relative w-96 px-14 py-4 rounded-md text-gray-800 mx-2' placeholder=' example@gmail.com'>
                        </input>
                        <img src={Newslettericon} className='email-icon top-32 left-7 mt-1 ' alt="" />
                        <a href='#' className=' mx-2 px-8 text-white leading-[50px] rounded-md bg-gray-800 '>Subscribe</a>
                    </div>
                </div>
            </div> */}

            <div className='service-section flex justify-between  border-b-2 mb-12 pt-12 pb-7 px-16 mx-10'>
                <div className='delivery flex align-bottom '>
                    <img src={SecureDelivery} className='icon w-12 h-12 mr-5' alt="" />
                    <div className='content'>
                        <h3>Fast & Secure Delivery</h3>
                        <p>Tell about your service</p>
                    </div>
                </div>
                <div className='guarantee flex'>
                    <img src={Guarantee} className='icon w-12 h-12 mr-5' alt="" />
                    <div className='content'>
                        <h3>Fast & Secure Delivery</h3>
                        <p>Tell about your service</p>
                    </div>
                </div>
                <div className='policy flex'>
                    <img src={Returnpolicy} className='icon w-12 h-12 mr-5' alt="" />
                    <div className='content'>
                        <h3>Fast & Secure Delivery</h3>
                        <p>Tell about your service</p>
                    </div>
                </div>
                <div className='support flex'>
                    <img src={Support} className='icon w-12 h-12 mr-5' alt="" />
                    <div className='content'>
                        <h3>Fast & Secure Delivery</h3>
                        <p>Tell about your service</p>
                    </div>
                </div>
            </div>

            <div className='footer-section px-20 flex justify-between pb-10  border-b-2 mx-10'>

                <div className='Support-part'>
                    <h3 className='font-bold leading-8'>Support</h3>
                    <p className='w-[155px] leading-8 text-gray-500 font-medium font-sans mb-4'>685 Market Street,
                        Las Vegas, LA 95820,
                        United States.</p>
                    <ul>
                        <li className='leading-9 text-gray-500 hover:text-gray-900 duration-300'><a href='#'><FontAwesomeIcon icon={faEnvelopeOpen} /> example@domain.com</a></li>
                        <li className='leading-9 text-gray-500 hover:text-gray-900 duration-300'><a href='#'><FontAwesomeIcon icon={faPhone} /> (+01) 850-315-5862</a></li>
                    </ul>

                </div>
                <div className='Account-part'>
                    <h3 className='font-bold leading-9'>Account</h3>
                    <ul>
                        <li className='leading-9 text-gray-500 font-semibold hover:text-gray-900 duration-300'><a href='#'>My Account</a></li>
                        <li className='leading-9 text-gray-500 font-semibold hover:text-gray-900 duration-300'><a href='#'>Login / Register</a></li>
                        <li className='leading-9 text-gray-500 font-semibold hover:text-gray-900 duration-300'><a href='#'>Cart</a></li>
                        <li className='leading-9 text-gray-500 font-semibold hover:text-gray-900 duration-300'><a href='#'>Wishlist</a></li>
                        <li className='leading-9 text-gray-500 font-semibold hover:text-gray-900 duration-300'><a href='#'>Shop</a></li>
                    </ul>
                </div>
                <div className='Quick-link-part'>
                    <h3 className='font-bold leading-9'>Quick Link</h3>
                    <ul>
                        <div className='relative group'>
                            <li className=' leading-9 text-gray-500 font-semibold hover:text-gray-900 duration-300 before:content-[""] before:w-0  before:duration-700 before:h-0.5 before:absolute before:bottom-1  before:bg-black before:opacity-0   before:group-hover:w-[100%] before:right-0 before:group-hover:left-0   before:group-hover:opacity-100 '><a href='#'>Privacy Policy</a></li>
                        </div>
                        <div className='relative group'>
                            <li className=' leading-9 text-gray-500 font-semibold hover:text-gray-900 duration-300 '><a href='#' className='before:content-[""] before:w-0  before:duration-700 before:h-0.5 before:absolute before:bottom-1  before:bg-black before:opacity-0   before:group-hover:w-[100%] before:right-0 before:group-hover:left-0   before:group-hover:opacity-100 '>Terms Of Use</a></li>
                        </div>
                        <div className='relative group'>
                            <li className=' leading-9 text-gray-500 font-semibold hover:text-gray-900 duration-300'><a href='#' className='before:content-[""] before:w-0  before:duration-700 before:h-0.5 before:absolute before:bottom-1  before:bg-black before:opacity-0   before:group-hover:w-10 before:right-16 before:group-hover:left-0   before:group-hover:opacity-100 '>FAQ</a></li>
                        </div>
                        <div className='relative group'>
                            <li className=' leading-9 text-gray-500 font-semibold hover:text-gray-900 duration-300 before:content-[""] before:w-0  before:duration-700 before:h-0.5 before:absolute before:bottom-1  before:bg-black before:opacity-0   before:group-hover:w-14 before:right-10 before:group-hover:left-0   before:group-hover:opacity-100 '><a href='#'>Contact</a></li>
                        </div>
                        <div className='relative group'>
                            <li className=' leading-9 text-gray-500 font-semibold hover:text-gray-900 duration-300 before:content-[""] before:w-0  before:duration-700 before:h-0.5 before:absolute before:bottom-1  before:bg-black before:opacity-0   before:group-hover:w-14 before:right-10 before:group-hover:left-0   before:group-hover:opacity-100 '><a href='#'>Contact</a></li>
                        </div>
                    </ul>
                </div>
                <div className='Download-part'>
                    <h3 className='font-bold leading-9'>Download App</h3>
                    <p className='w-56 mb-2 leading-9 text-gray-500'>Save $3 With App & New User only</p>
                    <div className='Qr-code-section flex'>
                        <div className='Qr-img'>
                            <img src={Qrscan} className='w-24 mr-3' alt="" />
                        </div>
                        <div className='App-img'>
                            <img src={Appstore} className='w-32 mb-4' alt="" />
                            <img src={Googleplay} className='w-32' alt="" />
                        </div>
                    </div>
                </div>
            </div>

            <div className='footer-bottom flex justify-between px-28 py-5'>
                <div className='social-icon'>
                    <ul className='flex '>
                        <li><a href='#' className='mr-4 text-gray-500'><FontAwesomeIcon icon={faFacebookF} /></a></li>
                        <li><a href='#' className='mr-4 text-gray-500'><FontAwesomeIcon icon={faInstagram} /></a></li>
                        <li><a href='#' className='mr-4 text-gray-500'><FontAwesomeIcon icon={faTwitter} /></a></li>
                        <li><a href='#' className='mr-4 text-gray-500'><FontAwesomeIcon icon={faLinkedinIn} /></a></li>
                        <li><a href='#' className='mr-4 text-gray-500'><FontAwesomeIcon icon={faDiscord} /></a></li>
                    </ul>
                </div>
                <div className='paragraph'>
                    <p className='text-gray-500'>© 2023. All rights reserved by Axilthemes.</p>
                </div>

                <div className='Accept-part '>
                    <ul className='flex justify-center'>
                        <li className='ml-3'>Accept For</li>
                        <li className='ml-3'><img src={Paypal} alt="" /></li>
                        <li className='ml-3'><img src={Mastercard} alt="" /></li>
                        <li className='ml-3'><img src={Visa} alt="" /></li>
                    </ul>
                </div>
            </div>
        </>
    )
}

export default Footer;
